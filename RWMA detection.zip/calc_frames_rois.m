function []= calc_frames_rois(start_frame,end_frame,size_of_roi_x,size_of_roi_y)

size_of_roi_x = 50;
size_of_roi_y = 50;

indexes_matrix = divide_to_rois(1280,720,size_of_roi_x,size_of_roi_y);

num_of_rows = size(indexes_matrix,1);
num_of_cols = size(indexes_matrix,2);
start_img_path = sprintf('%s%d%s','frame',start_frame,'.jpg');
BW = mark_ventricles(start_img_path);

for row=1:num_of_rows
    for col=1:num_of_cols
l        calc_frames(start_frame,end_frame,indexes_matrix(row,col).top_left.x,indexes_matrix(row,col).top_left.y,BW);
    end
end
end

