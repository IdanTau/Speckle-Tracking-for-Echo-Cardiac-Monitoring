%%% Mark solely the inside of the heart and make the image binary %%%
function mask = find_heart_3_mod(im, BW)
    %%% Make sure that the image is in grascale %%%
    if length(size(im)) == 3
        mask = rgb2gray(im);
    else
        mask = im;
    end
    %%% Seperates the inside of the heart %%%
    mask = logical(uint8((mask < 35 )) .* uint8(BW));
    se = strel('square',7);
    mask = imdilate(imerode(mask,se),se);
    mask = imfill(mask, 'holes');
	se = strel('square',7);
    mask = imerode(imdilate(mask,se),se);
    mask = imfill(mask,'holes');
    %%% Cast the mask to uint8 %%%
    mask = uint8(mask);
end