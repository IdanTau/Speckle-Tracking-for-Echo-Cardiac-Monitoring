function [indexes_matrix] = divide_to_rois(size_of_imgs_x,size_of_imgs_y,size_of_roi_x,size_of_roi_y)

%divide_to_rois(size(frame124_g,2),size(frame124_g,1),30,30)

%define a struct for each roi to save its indexes 
index = struct('x',[],'y',[]);
roi_indexes = struct('top_left',index,'size_x',0,'size_y',0);


%row, col- these are indexes in the answer matrix , and each cell in this
%matrix represent indexes of specific ROI. 

row=1;
col=1;
overlap=1.5;
for i = 1:size_of_roi_y:size_of_imgs_y
    for j = 1:size_of_roi_x:size_of_imgs_x
        indexes_matrix(row,col) = roi_indexes();
        indexes_matrix(row,col).top_left.x = j;
        indexes_matrix(row,col).top_left.y = i;
        indexes_matrix(row,col).size_x = min(floor(overlap*size_of_roi_x),size_of_imgs_x-(col-1)*size_of_roi_x);
        indexes_matrix(row,col).size_y = min(floor(overlap*size_of_roi_y),size_of_imgs_y-(row-1)*size_of_roi_y);
        col=col+1;
       
    end
   
    col=1;
    row=row+1;
    
end
    
end

