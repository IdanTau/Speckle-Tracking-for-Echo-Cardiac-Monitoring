%%% Seperates the clip to frames and saves them as different jpg files %%%
function extracted = extract_frames(clip_name)
    %%creates the folder for the frames%%
    path_name = pwd;
    %clip_name = "22weeks.avi";
    path_name = strcat(path_name, "\" , extractBefore(clip_name, "."));
    
    vid_obj = VideoReader(clip_name);
    mkdir(char(path_name));
    %%seperates the frames and saves them%%
    for img = 1 : vid_obj.NumberOfFrames;
        file_name = strcat (path_name, '\', 'frame', num2str(img), '.jpg');
        read_img = read(vid_obj, img);
        %imshow(read_img) %if you want to see every single frame
        imwrite(read_img, file_name);
    end
end