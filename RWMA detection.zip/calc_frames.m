function [mv_in_x,mv_in_y,roi_x_vec,roi_y_vec] = calc_frames(start_index,end_index,initial_x,initial_y,BW)
%assume that all frames are named "frame{index}.jpg",for example frame5.jpg
%example: calc_frames(1,200,911,348)

    %%
    size_of_roi_x = 50; 
    size_of_roi_y = 50; 
    n=size_of_roi_y/2;
    m=size_of_roi_x/2;
    %%

    roi_x = initial_x;
    roi_y = initial_y;
    mv_in_x = [];
    roi_x_vec = [];
    mv_in_y = []; 
    roi_y_vec = [];
 for i=start_index:end_index-1
     
     curr_img_name = sprintf('%s%d%s','frame',i,'.jpg');
     next_img_name = sprintf('%s%d%s','frame',i+1,'.jpg');
     
     
     
     [mat_error,is_all_black] = find_mat_error(curr_img_name,next_img_name,roi_x,roi_y,size_of_roi_x,size_of_roi_y,m,n,BW);
     if(not(is_all_black)) 
         [movement_in_x, movement_in_y] = find_avg_direction_vec(mat_error,m,n); 
     else
         [mv_in_x, mv_in_y,roi_x_vec,roi_y_vec] = deal(0);
         return
     end
         
         mv_in_x = [mv_in_x movement_in_x];
         mv_in_y = [mv_in_y movement_in_y];

         roi_x = floor(roi_x+movement_in_x);
         roi_y = floor(roi_y+movement_in_y);
         roi_x_vec = [roi_x_vec roi_x];
         roi_y_vec = [roi_y_vec roi_y];
     
         if (roi_y ~= mv_in_y)
            roi_y_vec
         end
            
        if mv_in_x ~= roi_x
            roi_x_vec
        end
end



disp("now plotting!");
 figure();
 subplot(2,2,1)
 plot(roi_x_vec);
 title('ROI location in x axis vs time');
 ylabel('pixels');
 hold all;


 subplot(2,2,2)
 plot(roi_y_vec);
 title('ROI location in y axis vs time');
 ylabel('pixels');


subplot(2,2,3)
 plot(mv_in_x);
 title('movement of ROI in x axis vs time');
 ylabel('pixels');

subplot(2,2,4)
 plot(mv_in_y);
 title('movement of ROI in y axis vs time');
 ylabel('pixels');
 
 hold all;
end
         
     
      
 

 
