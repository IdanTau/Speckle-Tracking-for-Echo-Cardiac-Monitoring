function [error_matrix,is_all_black] = find_mat_error(frame1,frame2,roi_x,roi_y,size_of_roi_x,size_of_roi_y,m,n,BW)

img1 = imread(frame1);
img2 = imread(frame2);
mask1 = find_heart_3_mod(img1,BW);
mask2 = find_heart_3_mod(img2,BW);
img1 = img1.*mask1;
img2 = img2.*mask2;


mat_error = zeros(2*n,2*m); %matrix of calculated errors, later we will find the minimum of this matrix

only_roi_img1 = img1(roi_y:min(roi_y+size_of_roi_y,size(img1,1)),roi_x:min(roi_x+size_of_roi_x,size(img1,2)));
only_roi_img2 = img2(roi_y:min(roi_y+size_of_roi_y,size(img2,1)),roi_x:min(roi_x+size_of_roi_x,size(img2,2)));
if(~any(only_roi_img1(:)) | ~any(only_roi_img2(:)))
    is_all_black= true ;
    disp("all is black!");
else  
    is_all_black = false;
    disp("not all is black!");
    %imshow(255*img1) %if you want to see each frame

    propos = size(img1);
    if length(propos)== 3
        img1_gs = rgb2gray(img1);
    else
          img1_gs = img1;
    end
    if length(propos)== 3
        img2_gs = rgb2gray(img2);
    else
          img2_gs = img2;
    end

    img1_gs=~img1_gs;
    img2_gs=~img2_gs;

   
    sum=0;

    for a=-m:m
        for b=-n:n
            for c=0:size_of_roi_x
                for d=0:size_of_roi_y
                        if (propos(2) >= roi_x+a+c) &&  (roi_x+a+c > 0)...
                           && (propos(1)>= roi_y+b+d) && (roi_y+b+d  > 0)...
                           && (propos(2) >= roi_x+c) && (roi_x+c > 0)...
                           && (roi_y+d > 0) && (roi_y+d  > 0)...
                           && sum ~= intmax

                                sum = sum + abs(img1_gs(roi_y + d,roi_x + c)-img2_gs(roi_y+b+d,roi_x+a+c));
                        else
                                sum = intmax;
                        end 
                end
            end
            mat_error(b+n+1,a+m+1)=sum;
            sum=0;    
        end

    end
end



%imshow(mat_error);

error_matrix = mat_error;
end
