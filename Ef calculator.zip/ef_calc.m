%%% A main function fo the ef calculation %%%
function ef = ef_calc(first_im_num,last_im_num)
    close all;
    biggest = 0;
    l_biggest = 0;
    big_index = 0;
    smallest = 0;
    l_smallest = 0;
    small_index = 0;
    big_mask = [];
    small_mask = [];
    %%% Getting the needed data from the  user%%%
    index = choose_im();
    heart_mask = mark_ventricles(sprintf("frame%d.jpg",index));
    %%% Calculates the left ventricle's area at EDV and ESV%%%
    for i = first_im_num : last_im_num
        im = imread(sprintf("frame%d.jpg",i));
        [mask,area,l_area] = find_heart_3(im,heart_mask);
        if i ==1
            biggest = area;
            l_biggest = l_area;
            big_index = i;
            big_mask = mask;
            smallest = area;
            l_smallest = l_area;
            small_index = i;
            small_mask = mask;
        elseif l_area > l_biggest
            biggest = area;
            l_biggest = l_area;
            big_index = i;
            big_mask = mask;
        elseif l_area < l_smallest
            smallest = area;
            l_smallest = l_area;
            small_index = i;
            small_mask = mask;
        end
    end
    %%% Output the results %%%
    l_ef = 100 * (l_biggest - l_smallest)/ l_biggest;
    figure('Name','EDV') ; hold on;
    imshow(imread(sprintf("frame%d.jpg",big_index)));
    figure('Name','EDV MASK') ; hold on;
    imshow(255 * big_mask);
    figure('Name','ESV') ; hold on;
    imshow(imread(sprintf("frame%d.jpg",small_index)));
    figure('Name','ESV MASK') ; hold on;
    imshow(255 .* small_mask);
    msgbox(sprintf('EF = %.1f%%',l_ef));

end