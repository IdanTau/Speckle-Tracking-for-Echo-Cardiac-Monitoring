%%% Let the user mark the ventricles of the heart %%%
function heart_mask = mark_ventricles(full_heart_im_path)
    close all;
    im = imread(full_heart_im_path);
    imshow(im); hold on;
    bw = drawpolygon();
    heart_mask = createMask(bw);
    msgbox('Got the polygon');
    close all;
end