%%% Mark solely the inside of the heart and make the image binary %%%
function [mask,area,l_area] = find_heart_3(im, BW)
    %%% Make sure that the image is in grascale %%%
    if length(size(im)) == 3
        mask = rgb2gray(im);
    else
        mask = im;
    end
    %%% Seperates the inside of the heart %%%
    mask = logical(uint8((mask < 35 )) .* uint8(BW));
    se = strel('square',7);
    mask = imdilate(imerode(mask,se),se);
    mask = imfill(mask, 'holes');
	se = strel('square',7);
    mask = imerode(imdilate(mask,se),se);
    mask = bwpropfilt(mask,'Area',1);
    mask = imfill(mask,'holes');
    %%% Calculates the area of the ventricles %%%
    area = regionprops(mask,'Area');
    r_area = min([area.Area]) ;
    l_area = max([area.Area]) ;
    area = sum([area.Area]);
    %%% Cast the mask to uint8 %%%
    mask = uint8(mask);
end