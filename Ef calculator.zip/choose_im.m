%%% Let the user choose and EDV image %%%
function index = choose_im()
    %%% Creating the UI %%%
    first_num = 1;
    im_list = first_num : first_num+14;
    fig = figure(1); hold on;
    sgtitle("Choose an image of the EDV");hold on;
    for i = 1:3
        for j = 1:5
            cur_num = (i -1) * 5 + j -1 + first_num;
            cur_loc = (i -1) * 5 + j ;
            im = imread(sprintf("frame%d.jpg",cur_num));
            subplot(3,5,cur_loc), imshow(im);hold on;
            title (sprintf("image %d",cur_num));
        end
    end
    H = gcf;
    set(H,'Visible', 'on');
    bt = uicontrol('Style', 'popup', 'String', string(im_list),...
        'Callback', {@popup_selection, H});
    uiwait(H);
    close all;
    
    %%% Getting the Index %%%
    function popup_selection(PopupH, EventData, H)
        index = get(PopupH, 'Value');
        H.UserData = index;
        uiresume;
        
    end
end


